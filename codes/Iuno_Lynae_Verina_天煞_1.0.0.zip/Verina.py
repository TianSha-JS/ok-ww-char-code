"""1.0.0 发布版的维里奈 E/R、跳 A 补协奏与 Q 交接动作。"""

from __future__ import annotations

import time

from src.char.BaseChar import SwitchPriority
from src.char.Verina import Verina as NativeVerina


class Verina(NativeVerina):
    """维里奈辅助动作；所有等待均有明确上限。"""

    AXIS_E_SETTLE = 0.16
    # 维里奈 R 动画短于琳奈，但首个冷却帧仍早于稳定回到队伍 HUD。
    AXIS_R_MIN_WAIT = 2.5
    AXIS_INTRO_WAIT = 1.3
    # 先完成起跳，再用 A 补足尚未满的协奏值。
    AXIS_JUMP_RISE = 0.12
    AXIS_A_GAP = 0.25
    AXIS_CONCERTO_TIMEOUT = 2.5

    def _axis_controller(self):
        for char in getattr(self.task, "chars", None) or ():
            if char is self:
                continue
            if getattr(char, "name", None) == "Iuno" and callable(
                    getattr(char, "run_team_turn", None)):
                return char
        return None

    def _axis_tick(self):
        self.check_combat()
        check_f_break = getattr(self.task, "check_f_break", None)
        if callable(check_f_break):
            check_f_break()

    def _axis_wait(self, duration: float):
        end = time.monotonic() + max(0.0, float(duration))
        while time.monotonic() < end:
            self._axis_tick()
            remaining = end - time.monotonic()
            if remaining <= 0:
                break
            self.sleep(min(0.05, remaining))

    def _axis_wait_intro(self):
        if self.has_intro:
            wait_intro = getattr(self, "wait_intro", None)
            if callable(wait_intro):
                wait_intro(time_out=self.AXIS_INTRO_WAIT, click=False)
            else:
                self._axis_wait(0.12)
            entered = getattr(self, "last_switch_in_time", -1)
            settle = max(0.9, getattr(self, "intro_motion_freeze_duration", 0.9)) + 0.12
            if entered >= 0:
                settle -= max(0.0, time.time() - entered)
            self._axis_wait(max(0.0, settle))
        return True

    def _axis_resonance_once(self):
        """在技能锁定期间重试 E，并确认 HUD 已接受本次施放。"""
        controller = self._axis_controller()
        if not controller or not controller._skill_until_cd(
                self, "resonance", allow_icon_drop=False):
            return False
        self._axis_wait(self.AXIS_E_SETTLE)
        return True

    def _axis_liberation_once(self):
        """重试 R，直到游戏确认本次施放。"""
        controller = self._axis_controller()
        kwargs = ({"on_return_frame": self._axis_jump_a_frame}
                  if getattr(self, "_axis_jump_preinput_enabled", False) else {})
        return bool(controller and controller._liberation_until_accepted(
            self, min_wait=self.AXIS_R_MIN_WAIT, **kwargs))

    def _axis_jump_input_allowed(self):
        visible, index, count = self.task.in_team()
        return (visible and count == 3 and index == self.index
                and not self.task.in_liberation)

    def _axis_jump_a_frame(self):
        """预输入一次跳跃，并只在协奏未满时发送 A。"""
        if not getattr(self, "_axis_jump_preinput_enabled", False):
            return False
        if not self._axis_jump_input_allowed():
            return False
        full = self.task.is_con_full()
        # 资源检测器可能刷新 HUD；检测后必须重新确认当前角色归属。
        if not self._axis_jump_input_allowed():
            return False
        if full:
            return True
        preinput = getattr(self, "_axis_r_confirming", False)
        started = getattr(self, "_axis_jump_started", None)
        if started is None:
            self._axis_jump_started = time.monotonic()
            self.task.jump(after_sleep=0.01)
            self.logger.info(f"[月琳维轴] 维里奈跳跃输入，R收尾预输入={preinput}")
            return self._axis_jump_input_allowed()
        now = time.monotonic()
        if now - started >= self.AXIS_CONCERTO_TIMEOUT:
            return True
        last_a = getattr(self, "_axis_last_a_at", None)
        ready = (now - started >= self.AXIS_JUMP_RISE if last_a is None
                 else now - last_a >= self.AXIS_A_GAP)
        if ready:
            if getattr(self, "_axis_first_a_at", None) is None:
                self._axis_first_a_at = now
            self._axis_last_a_at = now
            self.click(interval=0)
            self._axis_a_presses = getattr(self, "_axis_a_presses", 0) + 1
            self.logger.info(f"[月琳维轴] 维里奈 A{self._axis_a_presses} 输入，"
                             f"R收尾预输入={preinput}，距跳跃={now - started:.3f}秒")
        return self._axis_jump_input_allowed()

    def _axis_fill_concerto(self):
        """协奏达到满值即停止普攻，不等待固定连段。"""
        started = getattr(self, "_axis_jump_started", None)
        end = (time.monotonic() if started is None else started) + self.AXIS_CONCERTO_TIMEOUT
        while time.monotonic() < end:
            self.task.next_frame()
            visible, index, count = self.task.in_team()
            if not visible or count != 3:
                self.sleep(0.05, check_combat=False)
                continue
            if index != self.index:
                return False
            self._axis_tick()
            if not self._axis_jump_input_allowed():
                return False
            full = self.task.is_con_full()
            if not self._axis_jump_input_allowed():
                return False
            if full:
                self.logger.info(f"[月琳维轴] 维里奈协奏已满，停止 A 并接 Q，"
                                 f"A次数={self._axis_a_presses}")
                return True
            if not self._axis_jump_a_frame():
                return False
            self.sleep(0.05, check_combat=False)
        self.logger.warning(f"[月琳维轴] 维里奈跳 A 补协奏超时，A次数={self._axis_a_presses}")
        return False

    def _axis_echo_once(self):
        """重试 Q，直到冷却状态确认本次施放。"""
        controller = self._axis_controller()
        if not controller or not controller._skill_until_cd(self, "echo"):
            return False
        return True

    def do_perform(self):
        controller = self._axis_controller()
        if controller is not None:
            return controller.run_team_turn(self)
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False,
                            target_low_con=False):
        controller = self._axis_controller()
        target = getattr(controller, "_ylv_target", None) if controller else None
        if target:
            return SwitchPriority.MUST if self.name == target else SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def healer_full_con_switch_locked(self):
        controller = self._axis_controller()
        if controller is not None and getattr(controller, "_ylv_target", None) == self.name:
            return False
        return super().healer_full_con_switch_locked()

    def ylv_er_jump_aaq(self):
        """执行 E/R，跳起并用 A 补满协奏，再施放 Q 并交接。"""
        self._axis_jump_started = self._axis_first_a_at = self._axis_last_a_at = None
        self._axis_a_presses = 0
        self._axis_jump_preinput_enabled = self._axis_r_confirming = False
        try:
            self._axis_wait_intro()
            if not self._axis_resonance_once():
                return False
            self._axis_jump_preinput_enabled = self._axis_r_confirming = True
            if not self._axis_liberation_once():
                return False
            self._axis_r_confirming = False
            if not self._axis_fill_concerto():
                return False
            return self._axis_echo_once()
        finally:
            self._axis_jump_preinput_enabled = self._axis_r_confirming = False
            self._axis_jump_started = self._axis_first_a_at = self._axis_last_a_at = None
            self._axis_a_presses = 0
